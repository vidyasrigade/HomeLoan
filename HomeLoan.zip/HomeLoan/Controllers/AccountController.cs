﻿using HomeLoan.Data;
using HomeLoan.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HomeLoan.Controllers
{
    public class AccountController : Controller
    {
        private readonly AppDbContext _db;
        public AccountController(AppDbContext db) => _db = db;

        // ---------- REGISTER ----------
        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(AppUser user)
        {
            ModelState.Clear();
            if (!ModelState.IsValid)
            {
                TempData["ErrorMessage"] = "Please fill all fields correctly.";
                return View(user);
            }

            bool emailExists = await _db.AppUsers.AnyAsync(u => u.Email == user.Email);
            if (emailExists)
            {
                TempData["ErrorMessage"] = "This email is already registered. Please login.";
                return View(user);
            }

            _db.AppUsers.Add(user);
            await _db.SaveChangesAsync();

            HttpContext.Session.SetInt32("UserId", user.Id);
            HttpContext.Session.SetString("UserEmail", user.Email);
            HttpContext.Session.SetString("UserName", user.FirstName + user.LastName);

            TempData["SuccessMessage"] = "Registration successful! Welcome to HomeLoan.";
            return RedirectToAction("Dashboard");
        }

        // ---------- LOGIN ----------
        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(string email, string password)
        {
            if (email == "admin@hotmail.com" && password == "Test@123")
            {
                //user = "admin@hotmail.com";
                HttpContext.Session.SetString("IsAdmin", "true");
                HttpContext.Session.SetString("UserEmail", email);
                TempData["SuccessMessage"] = "Welcome back, Admin!";
                return RedirectToAction("Dashboard", "Admin");
            }


            var user = await _db.AppUsers
                    .FirstOrDefaultAsync(u => u.Email == email && u.PasswordHash == password);

            if (user == null)
            {
                TempData["ErrorMessage"] = "Invalid email or password.";
                return View();
            }

            HttpContext.Session.SetInt32("UserId", user.Id);
            HttpContext.Session.SetString("UserEmail", user.Email);
            HttpContext.Session.SetString("UserName", user.FirstName+user.LastName);
            HttpContext.Session.SetString("IsAdmin", "false");

            TempData["SuccessMessage"] = $"Welcome back, {user.FirstName+user.LastName}!";
            return RedirectToAction("Dashboard", "Account");
        }
        [HttpGet]
        public IActionResult ForgotPassword()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ForgotPassword(string email)
        {
            var user = await _db.AppUsers.FirstOrDefaultAsync(u => u.Email == email);
            if (user == null)
            {
                TempData["ErrorMessage"] = "No account found with that email.";
                return View();
            }

            // TODO: Send password reset email or show reset instructions
            TempData["SuccessMessage"] = "If your email is registered, you will receive password reset instructions.";
            return RedirectToAction("Login");
        }

        // ---------- DASHBOARD ----------
        [HttpGet]
        public async Task<IActionResult> Dashboard()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                TempData["ErrorMessage"] = "Please login first to access your dashboard.";
                return RedirectToAction("Login");
            }

            var user = await _db.AppUsers.FindAsync(userId);
            var loans = await _db.LoanApplications
                                 .Where(l => l.UserId == userId)
                                 .ToListAsync();

            ViewBag.User = user;
            return View(loans);     // uses Views/Account/Dashboard.cshtml
        }

        // ---------- LOGOUT ----------
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            TempData["SuccessMessage"] = "You have successfully logged out.";
            return RedirectToAction("Index", "Home");
        }
    }
}
