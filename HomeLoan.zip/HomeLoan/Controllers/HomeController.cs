using Microsoft.AspNetCore.Mvc;
using HomeLoan.Data;
using Microsoft.EntityFrameworkCore;
using HomeLoan.Models;

namespace HomeLoan.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _db;
        public HomeController(AppDbContext db) => _db = db;

        public IActionResult Index() => View();

        public IActionResult Calculator() => View();

        public IActionResult FAQ() => View();

        public IActionResult AboutUs() => View();
        [HttpGet]
        public IActionResult Contact() => View();

        [HttpPost]
        public IActionResult Contact(string name, string email, string message)
        {
            TempData["Msg"] = "Thank you for contacting us, " + name + "! We�ll get back soon.";
            return RedirectToAction("Contact");
        }

       
    }
}

