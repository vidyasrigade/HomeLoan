﻿using Microsoft.AspNetCore.Mvc;
using HomeLoan.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace HomeLoan.Controllers
{
    public class AdminController : Controller
    {
        private readonly AppDbContext _db;
        private readonly IConfiguration _config;
        public AdminController(AppDbContext db, IConfiguration config)
        {
            _db = db;
            _config = config;
        }

        [HttpGet]
        
        public IActionResult Login() => View();

        [HttpPost]
        [AutoValidateAntiforgeryToken]
        public IActionResult Login(string username, string password)
        {
            if (username == "admin@hotmail.com" && password == "Test@123")
            {
                HttpContext.Session.SetString("IsAdmin", "true");
                return RedirectToAction("Dashboard", "admin");
                
            }
            ViewBag.Error = "Invalid Username or Password";
            return View();
        }
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            TempData["SuccessMessage"] = "You have logged out.";
            return RedirectToAction("Login");
        }

        public async Task<IActionResult> Dashboard()
        {
            if (HttpContext.Session.GetString("IsAdmin") != "true")
                return RedirectToAction("Login");

            var apps = await _db.LoanApplications.OrderByDescending(x => x.AppliedOn).ToListAsync();
            return View(apps);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateStatus(int id, string status)
        {
            var loan = await _db.LoanApplications.FindAsync(id);
            if (loan != null)
            {
                loan.Status = status;

                // When approved -> create account if not present (per doc)
                if (status == "Approved" && string.IsNullOrEmpty(loan.AccountNumber))
                {
                    loan.AccountNumber = GenerateAccountNumber();
                    loan.AccountCreatedOn = DateTime.UtcNow;
                    loan.AccountBalance = (decimal?)loan.LoanAmount; // mock disbursal
                }

                await _db.SaveChangesAsync();
            }
            return RedirectToAction("Dashboard");
        }

        public async Task<IActionResult> ViewDocuments(int loanId)
        {
            if (HttpContext.Session.GetString("IsAdmin") != "true")
                return RedirectToAction("Login");

            var docs = await _db.Documents.Where(d => d.LoanApplicationId == loanId).ToListAsync();
            ViewBag.LoanId = loanId;
            return View(docs);
        }

        // helper
        private string GenerateAccountNumber()
        {
            // Example account number generator: HL + yyyyMMdd + 6 random digits
            var rnd = new Random();
            var suffix = rnd.Next(100000, 999999).ToString();
            return "HL" + DateTime.UtcNow.ToString("yyyyMMdd") + suffix;
        }

    }
}

