﻿using System.ComponentModel.DataAnnotations;

namespace HomeLoan.ViewModels
{
    public class LoanApplicationViewModel
    {
        public int Id { get; set; }

        [Required, Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [DataType(DataType.Date)]
        public DateTime DOB { get; set; }

        public string AadharNumber { get; set; }

        [MaxLength(10, ErrorMessage ="PAN Number must be at most 10 characters.")]
        public string PanNumber { get; set; }

        public string PropertyName { get; set; }

        public decimal EstimatedPropertyCost { get; set; }

        [Display(Name = "Loan Amount")]
        public decimal LoanAmount { get; set; }

        [Display(Name = "Tenure (Years)")]
        public int TenureYears { get; set; } = 5;

        [Display(Name = "Interest Rate (%)")]
        public decimal InterestRate { get; set; } = 8.5M;
    }
}
