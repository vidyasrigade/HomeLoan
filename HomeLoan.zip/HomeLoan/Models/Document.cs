﻿using System;

namespace HomeLoan.Models
{
    public class Document
    {
        public int Id { get; set; }
        public int LoanApplicationId { get; set; }
        public LoanApplication LoanApplication { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        // web-accessible path e.g. /uploads/{appId}/{file}
        public string DocumentType { get; set; }
        // e.g. "Aadhar", "PAN", "SalarySlip"
        public DateTime UploadedOn { get; set; } = DateTime.UtcNow;
    }
}
