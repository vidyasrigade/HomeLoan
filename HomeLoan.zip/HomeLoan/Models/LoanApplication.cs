﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HomeLoan.Models
{
    public class LoanApplication
    {
        public int Id { get; set; }

        // link to user who created this application (optional)
        public int? UserId { get; set; }
        public AppUser User { get; set; }

        [Required, MaxLength(100)]
        public string FirstName { get; set; }

        [MaxLength(100)]
        public string LastName { get; set; }

        [DataType(DataType.Date)]
        public DateTime DOB { get; set; }

        [MaxLength(12)]
        public string AadharNumber { get; set; }

        [MaxLength(10)]
        public string PanNumber { get; set; }

        public string PropertyName { get; set; }
        public decimal EstimatedPropertyCost { get; set; }
        public decimal LoanAmount { get; set; }
        public int TenureMonths { get; set; }
        public decimal InterestRate { get; set; }

        public string Status { get; set; } = "Sent for verification";
        public DateTime AppliedOn { get; set; } = DateTime.UtcNow;

        // Account creation after approval
        public string AccountNumber { get; set; }
        public DateTime? AccountCreatedOn { get; set; }
        public decimal? AccountBalance { get; set; } // amount disbursed
    }
}
