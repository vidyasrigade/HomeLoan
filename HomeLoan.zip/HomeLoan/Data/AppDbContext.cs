﻿using HomeLoan.Models;
using Microsoft.EntityFrameworkCore;

namespace HomeLoan.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<AppUser> AppUsers { get; set; }
        public DbSet<LoanApplication> LoanApplications { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AppUser>().ToTable("AppUsers");
            modelBuilder.Entity<LoanApplication>().ToTable("LoanApplications");

        }
        public DbSet<Document> Documents { get; set; }
    }
}
